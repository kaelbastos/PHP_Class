<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .cabecalho{
            background: gray;
            height: 60px;
            width: 100%;
            margin: 0px ;
            margin-left: 0px;


            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            color: white;
            font-size: larger;
            text-align: center;
            line-height: 60px;
        }
    </style>
</head>
<body>
    <div class="cabecalho">
           Avaliação 1!
    </div>
</body>
</html>