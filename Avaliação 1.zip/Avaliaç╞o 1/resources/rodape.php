<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .rodape{
            clear: both;
            background: gray;
            height: 60px;
            width: 100%;
            padding: 0px;
            margin: 0px;
            margin-top: 30px;

            font-size: medium;
            text-align: center;
            line-height: 60px;

            position: relative;
            bottom: 0px;
            
        }
    </style>
</head>
<body>
    <div class="rodape">
        Copyrigth © 2021 - Kael L. Bastos
    </div>
</body>
</html>