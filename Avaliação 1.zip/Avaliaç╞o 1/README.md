# Observações

A pasta deve ser colocada diretamente na diretório root do servidor para não gerar conflito de localização dos arquivos.

### A localização do arquivo _"students.json"_ deve ser alterada nos arquivos:
* _getStudents.php_ (linha 3);
* _process.php_ (linha 115);


_Caso queira, poderá ser colocado o arquivo __"favicon.ico"__ no root da pasta do servidor para que o navegador possa exibir o icone desenhado. Essa opção foi mais um detalhe na brincadeira, mas contribui para o estilo do site._

